package com.microsoftwo.clother.adviceBoard.command.application.service;

import com.microsoftwo.clother.adviceBoard.command.application.dto.PostRequestDTO;



public interface BoardCommandService {
    PostRequestDTO createBoard(int userId, String title, String content);
}
