package com.microsoftwo.clother.adviceBoard.command.application.controller;

import com.microsoftwo.clother.adviceBoard.command.application.dto.PostRequestDTO;
import com.microsoftwo.clother.adviceBoard.command.application.service.BoardCommandService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/boards")
@Slf4j
public class BoardCommandController {

    private  BoardCommandService boardCommandService;

    public BoardCommandController(BoardCommandService boardCommandService) {
        this.boardCommandService = boardCommandService;
    }

    @GetMapping("/create")
    public ResponseEntity<String> testGetMethod() {
        return ResponseEntity.ok("GET 요청 성공!");
    }

    // 게시글 등록
    @PostMapping("/create")
    public ResponseEntity<PostRequestDTO> createBoard(@RequestBody PostRequestDTO request) {
        PostRequestDTO savedBoard = boardCommandService.createBoard(request.getUserId(),request.getTitle(), request.getContent());
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBoard);
    }
}

