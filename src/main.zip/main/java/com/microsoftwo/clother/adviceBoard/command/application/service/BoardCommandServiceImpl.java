package com.microsoftwo.clother.adviceBoard.command.application.service;


import com.microsoftwo.clother.adviceBoard.command.application.dto.PostRequestDTO;
import com.microsoftwo.clother.adviceBoard.command.domain.aggregate.BoardEntity;
import com.microsoftwo.clother.adviceBoard.command.domain.repository.BoardCommandRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Service;

@Service
@Setter
@NoArgsConstructor
public class BoardCommandServiceImpl implements BoardCommandService {

    private BoardCommandRepository boardCommandRepository;

    public BoardCommandServiceImpl(BoardCommandRepository boardCommandRepository) {
        this.boardCommandRepository = boardCommandRepository;
    }

    @Override
    public PostRequestDTO createBoard(int userId, String title, String content) {
        // 1. 새로운 BoardEntity 생성
        BoardEntity boardEntity = new BoardEntity();
        boardEntity.setUserId(userId);
        boardEntity.setTitle(title);
        boardEntity.setContent(content);

        // 2. 저장 후 반환
        BoardEntity savedEntity = boardCommandRepository.save(boardEntity);

        // 3. 저장된 Entity를 DTO로 변환해서 반환
//        return new PostRequestDTO(savedEntity.getId(), savedEntity.getTitle(), savedEntity.getContent());
        return PostRequestDTO.fromEntity(savedEntity);
    }
}

