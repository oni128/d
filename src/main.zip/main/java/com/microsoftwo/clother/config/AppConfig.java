package com.microsoftwo.clother.config;

public class AppConfig {
}
